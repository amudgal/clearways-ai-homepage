#!/bin/bash
cd /var/app/current
npm run migrate || true
